import datetime
import sqlalchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from .db_session import SqlAlchemyBase


class Text(SqlAlchemyBase, UserMixin):  # наследуем на основе класса SqlAlchemyBase и UserMixin
    __tablename__ = 'article'     #  Для UserMixin принципиально, чтобы был ключ id

    id = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, autoincrement=True)
    name = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    text = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    

    def __repr__(self):
        return f'Пользователь:  {self.idu} {self.name}'