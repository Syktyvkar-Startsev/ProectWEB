import sqlalchemy
from sqlalchemy.ext.declarative import declarative_base  

SqlAlchemyBase = declarative_base() #абстрактная база для наследования моделей

__factory = None # переменная для работы с сессиями


def global_init(db_file):
    global __factory

    if __factory: #если сессия уже создана, то выходим
        return

    if not db_file or not db_file.strip():
        raise Exception("Надо задать имя файла базы данных.")

    conn_str = f'sqlite:///{db_file.strip()}?check_same_thread=False' #дополнительный параметр указан 
						#	для разрешения множественного доступа
    print(f"Подключение к базе данных по адресу {conn_str}") #Выводим сообщение для информирования пользователя

    engine = sqlalchemy.create_engine(conn_str, echo=False) # Falseотключает вывод SQL-запросов в консоль
    __factory = sqlalchemy.orm.sessionmaker(bind=engine)

    # Подгружаем здесь все дополнительные классы. Классы храним в этой же папке с одноименными названиями 
    # и расширением py. Первоначально эти файлы пустные
    from . import users
    from . import rubriks
    from . import news

    SqlAlchemyBase.metadata.create_all(engine)


def create_session() -> sqlalchemy.orm.Session:
    global __factory
    return __factory()


