from flask_wtf import FlaskForm
from wtforms import SubmitField, StringField, PasswordField
from wtforms.fields.html5 import EmailField
from wtforms.validators import DataRequired


class Form(FlaskForm):
    name = StringField('Название', validators=[DataRequired()])
    text = EmailField('Текст статьи', validators=[DataRequired()])
    submit = SubmitField('Создать')
