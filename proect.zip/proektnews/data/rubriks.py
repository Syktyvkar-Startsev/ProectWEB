import sqlalchemy

from .db_session import SqlAlchemyBase


class Rubrik(SqlAlchemyBase):
    __tablename__ = 'rubriks'
    idr = sqlalchemy.Column(sqlalchemy.Integer, primary_key=True, 
                           autoincrement=True)
    rubrik = sqlalchemy.Column(sqlalchemy.String, nullable=True)
    news = sqlalchemy.orm.relation("News", back_populates='rubrik')