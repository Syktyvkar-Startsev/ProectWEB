from flask import Flask, render_template, redirect
from data import db_session # Грузим из нашей папки data
from data.reg import RegForm
from data.newarticle import Form
from data.users import User
from data.news import News
from data.article import Text
from flask_login import LoginManager, login_user, login_required, logout_user
from data.login_form import LoginForm


app = Flask(__name__)
app.config['SECRET_KEY'] = 'sgu_secret_key'

login_manager = LoginManager() #инициализация flask-login
login_manager.init_app(app)


def main():
    db_session.global_init("db/news.sqlite") # При первом запуске будет создан файл news.sqlite

    @app.route('/')
    def index():
        #session = db_session.create_session()
        #posts = session.query(News)
        session = db_session.create_session()
        #session.query(User).delete()   #Убрать комментарий в двух строках
        #session.commit()               # и будет очищаться таблица
        news = session.query(Text)
        return render_template('news1.html', title='Новости', users = news)

    @login_manager.user_loader #Для flask-login обязательна функция
    def load_user(user_id):
        session = db_session.create_session()
        return session.query(User).get(user_id)

    @app.route('/login', methods=['GET', 'POST'])
    def login():
        form = LoginForm()
        if form.validate_on_submit():
            session = db_session.create_session()
            user = session.query(User).filter(User.email == form.email.data).first()
            if user and user.check_password(form.password.data):
                login_user(user, remember=form.remember_me.data)
                return redirect("/")
            return render_template('login.html', message="Неверный email или пароль", form=form)
        return render_template('login.html', title='Авторизация', form=form)

    @app.route('/logout')
    @login_required
    def logout():
        logout_user()
        return redirect("/")

    @app.route('/index')
    def index1():
        return redirect('/')
    
  
    
    @app.route('/list')
    def list():
        session = db_session.create_session()
        #session.query(User).delete()   #Убрать комментарий в двух строках
        #session.commit()               # и будет очищаться таблица
        users = session.query(User)
        return render_template('list.html', title='Список авторов', users=users)

    @app.route('/reg', methods=['GET', 'POST'])
    def register():
        form = RegForm()
        if form.validate_on_submit():
            if form.password.data != form.password_again.data:
                return render_template('reg.html', title='Регистрация', form=form,
                                       message="Пароли не совпадают")
            session = db_session.create_session()
            if session.query(User).filter(User.email == form.email.data).first():
                return render_template('reg.html', title='Регистрация', form=form,
                                       message="Такой пользователь уже существует")
            user = User(
                name=form.name.data,
                email=form.email.data
            )
            user.set_password(form.password.data)
            #print(user)
            session.add(user)
            session.commit()
            return redirect('/')
        return render_template('reg.html', title='Регистрация', form=form)
    @app.route('/article')
    def article():
        form = Form()
        if form.validate_on_submit():
            session = db_session.create_session()
            user = User(
                name=form.name.data,
                Text=form.email.data
            )
            #user.set_password(form.password.data)
            #print(user)
            session.add(article)
            session.commit()
            return redirect('/')
        return render_template('article.html', title='Новая статья', form=form)
    app.run(port=8080, host='127.0.1.1')
  
    
    

if __name__ == '__main__':
    main()
